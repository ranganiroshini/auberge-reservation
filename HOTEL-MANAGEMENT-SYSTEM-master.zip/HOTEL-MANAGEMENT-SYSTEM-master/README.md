# HOTEL-MANAGEMENT-SYSTEM
HOTEL MANAGEMENT SYSTEM USING TKINTER AND SQLITE3
## General info
* In i have used tkinter libary from python to build the GUI.
* To store the details of customer i have used sqlite3 database.
* You can Check In, Check Out, see customer details, room wise customer details in this project

## HOW TO RUN?
Run main.py file
